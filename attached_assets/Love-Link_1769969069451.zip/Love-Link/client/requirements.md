## Packages
framer-motion | Complex animations and page transitions
@tsparticles/react | Particle effects for the starry background
@tsparticles/slim | Lightweight particle engine
lucide-react | Icons for the UI

## Notes
- The app uses a single page with multiple steps/states (Universe -> Story -> Calculator -> Final Message).
- Requires a backend endpoint POST /api/love-logs to save the names in the love calculator step.
